#include "stdafx.h"
#include "observer.h"


observer::observer()
{
}


observer::~observer()
{
}
