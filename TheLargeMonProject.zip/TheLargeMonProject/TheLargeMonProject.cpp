// TheLargeMonProject.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Controller.h"
int main()
{
	Controller con;// the contoller
	int x;
	cout << "Press 1 to start the game" << endl;
	cout << "Press 0 to exit the game" << endl;
	cin >> x;
	vector <Player *> m_Player(2);
	if (x == 1)
	{
		int x;
		cout << "Press 1 to add a player" << endl;
		cin >> x;
		if (x == 1)
		{
			int x;
			string xword;
			cout << "Type in players name" << endl;
			cin >> xword;
			Player p1(xword);
			m_Player[0] = &p1;
			Player com("COM");
			m_Player[1] = &com;
			cout << m_Player[0]->getName() << " has been created and " << m_Player[1]->getName() << " has been created" << endl;
			cout << "Press 1 to generate largemon" << endl;
			cin >> x;
			if (x == 1)
			{

				con.assignLargemonToPlayer(*m_Player[0], *m_Player[1]);
				cout << "generated" << endl;
				cout << "Combat begin" << endl;
				Combat session;
				session.initCombat(*m_Player[0]);
				int option;
				cout << "Combat Begins" << endl;
				session.setTurn(true);
				int exitGame = 1;
				while (exitGame != 0 )
				{
					exitGame = con.checkGameStatus(*m_Player[0], *m_Player[1]);
					con.gameSession(*m_Player[0], *m_Player[1]);
					con.displayHealthPoints(*m_Player[0], *m_Player[1]);
				}
			}
			else {
				cout << "" << endl;
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else {
		return 0;
	}	
}

